package app;

import view.JuegoView;

public class App {
    public static void main(String[] args) {
        JuegoView.main(args);
    }
}
